# virtual environment

##### 생성

```shell
$ python -m venv [가상환경이름]
$ source [가상환경이름]/Scripts/activate

(가상환경이름)
$
```



##### 활성화

```shell
$ source [가상환경이름]\Scripts\activate
```



##### 비활성화

```shell
$ deactivate
```

